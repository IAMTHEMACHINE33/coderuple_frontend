"use strict";
exports.id = 816;
exports.ids = [816];
exports.modules = {

/***/ 8468:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./src/Images/fb1.png
/* harmony default export */ const fb1 = ({"src":"/_next/static/media/fb1.a557a52c.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAIAAABLbSncAAAAuElEQVR42mOwjpwBRDaRMxR9Jpe3rsmvW2kQPNU2agYDUNQpdiaDXf+aTSf+//9/8OhVBvt+57hZDFYR012AlEzHo8evzpy/w6Db7Ro/CyjIAJQEKjl8/BpQ+Z8/fzbvPMtg2wdSahc1wyhkWlnLmtdvP969/zy1bCmQaxc9A2SUW/wsBoZmoOjBY1eBDI/E2UBBmOXmvfcevDh68jqDfjfQHKAgA8SthsHTgA4FmgN0q03UDKuI6QAgE139oLKQIwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/Images/iglogog.svg
/* harmony default export */ const iglogog = ({"src":"/_next/static/media/iglogog.349b2695.svg","height":61,"width":58,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/Images/lilogo.svg
/* harmony default export */ const lilogo = ({"src":"/_next/static/media/lilogo.dfe8ec79.svg","height":58,"width":55,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/Images/twitterlogo.svg
/* harmony default export */ const twitterlogo = ({"src":"/_next/static/media/twitterlogo.ddf4c7e4.svg","height":58,"width":61,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/Images/phone.svg
/* harmony default export */ const phone = ({"src":"/_next/static/media/phone.990408c9.svg","height":72,"width":71,"blurWidth":0,"blurHeight":0});
;// CONCATENATED MODULE: ./src/Images/mail.svg
/* harmony default export */ const mail = ({"src":"/_next/static/media/mail.e533f486.svg","height":79,"width":78,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/Footer.jsx









const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "relative flex flex-col items-center justify-center w-full footer-container",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
                className: "responsive-container flex flex-col items-start  justify-start gap-5 bottom-0 p-5 left-0 z-20 md:flex md:flex-row  md:justify-between md:p-6",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "grid grid-row-3 grid-flow-row gap-1.5 justify-center text-center ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-4xl text-white italic text-left font-medium",
                                children: "Contact Us"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-s text-white text-left",
                                children: "Let's work together!"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " justify-center flex flex-col flex-nowrap gap-3 mt-2 mb-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        placeholder: "Full Name",
                                        className: "py-1.5 px-4 rounded-lg outline-none"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        placeholder: "Email",
                                        className: "py-1.5 px-4 rounded-lg outline-none"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("textarea", {
                                        type: "text",
                                        placeholder: "Message",
                                        className: "py-1.5 px-4 rounded-lg h-36 outline-none "
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        type: "submit",
                                        placeholder: "Submit",
                                        className: " bg-[#6096ba] py-1.5 px-4 rounded-3xl text-white  w-32 mt-4",
                                        children: "SUBMIT"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "grid grid-row-3 grid-flow-row gap-1.5 text-left",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-4xl text-white italic gap-0 text-left",
                                children: "Coderuple"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-s text-white text-left ",
                                children: "All of our pages"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                className: " justify-center text-left text-white flex flex-col flex-nowrap gap-0 sm:gap-0  items-left  lg:text-lg   mt-0 sm:dark:text-black-400 text-lg max-w-full  mb-0 sm:mr-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "#",
                                            className: " hover:underline  ",
                                            children: "- Home"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/services",
                                            className: " hover:underline ",
                                            children: "- Our Services"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#",
                                            className: "hover:underline  ",
                                            children: "- Our Works"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                            href: "/contact",
                                            className: "hover:underline",
                                            children: "- Contact Us"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: "#",
                                            className: "hover:underline",
                                            children: "- Careers"
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                        className: "grid grid-flow-row gap-1.5 justify-center text-left  ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-4xl text-white italic",
                                children: "Coderuple"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "text-s text-white ",
                                children: "Where your business blooms!"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row gap-1.5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: phone,
                                        className: "w-8 h-8 mt-2",
                                        alt: "image"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex flex-col",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-white ",
                                                children: "+977 9841709097"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                className: "text-white ",
                                                children: "+977 9813643643"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-row gap-1.5",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: mail,
                                        className: "w-8 h-8",
                                        alt: "image"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "text-white",
                                        children: "coderupleglobal@gmail.com"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " flex gap-2 ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: fb1,
                                            className: "w-8 h-8",
                                            alt: "image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: iglogog,
                                            className: "w-8 h-8",
                                            alt: "image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: lilogo,
                                            className: "w-8 h-8",
                                            alt: "image"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                            src: twitterlogo,
                                            className: "w-8 h-8 ",
                                            alt: "image"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "copyright_container flex justify-center py-2 w-full",
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "text-white",
                    children: "Copyright 2023 All rights reserved coderuple"
                })
            })
        ]
    });
};
/* harmony default export */ const components_Footer = (Footer);


/***/ }),

/***/ 9231:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Navbar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./src/Images/logo.png
var logo = __webpack_require__(2573);
;// CONCATENATED MODULE: ./src/SVG/menu.svg
/* harmony default export */ const menu = ({"src":"/_next/static/media/menu.863dc2f1.svg","height":24,"width":24,"blurWidth":0,"blurHeight":0});
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./src/components/Navbar.jsx






const Navbar = ()=>{
    //navbar scroll when active state
    const [navbar, setNavbar] = (0,external_react_.useState)(false);
    //logo scroll when active
    const [navbarLogo, setNavbarLogo] = (0,external_react_.useState)(logo/* default */.Z);
    //navbar scroll changeBackground function
    const changeBackground = ()=>{
        // console.log(window.scrollY)
        if (window.scrollY >= 40) {
            setNavbar(true);
        } else {
            setNavbar(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        changeBackground();
        // adding the event when scroll change background
        window.addEventListener("scroll", changeBackground);
    });
    //logo scroll function
    const changeLogo = ()=>{
        if (window.scrollY >= 60) {
            setNavbarLogo(logo/* default */.Z);
        } else {
            setNavbarLogo(logo/* default */.Z);
        }
    };
    (0,external_react_.useEffect)(()=>{
        changeLogo();
        // adding the event when scroll change Logo
        window.addEventListener("scroll", changeLogo);
    });
    return(// <nav className={navbar ? "navbar__container navbar__container__sticky" : "navbar__container navbar__container__absolute"}>
    //   <div className="responsive-container flex justify-between items-center ">
    //     <span className="font-semibold text-lg flex items-center gap-2 h-full py-4">
    //       <Image src={logo} height={30} />
    //       CODERUPLE
    //     </span>
    //     <Image src={menu} className="sm:hidden" />
    //     <div className="gap-4 hidden sm:flex">
    //       <span className="nav__links">Home</span>
    //       <div class="popover__wrapper">
    //         <a href="#">
    //           <h2 class="popover__title nav__links">Our Services</h2>
    //         </a>
    //         <div class="popover__content">
    //           <p class="popover__message">cHECHK</p>
    //         </div>
    //       </div>
    //       <span className="nav__links">Our Works</span>
    //       <span className="nav__links">Contact Us</span>
    //       <span className="nav__links">Careers</span>
    //     </div>
    //   </div>
    // </nav>
    /*#__PURE__*/ jsx_runtime_.jsx("nav", {
        className: navbar ? "navbar__container navbar__container__sticky" : "navbar__container navbar__container__absolute",
        "data-te-navbar-ref": true,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            class: "flex responsive-container flex-wrap items-center justify-between ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    className: "font-semibold text-lg flex items-center gap-2 h-full py-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: logo/* default */.Z,
                            height: 30,
                            alt: "image"
                        }),
                        "CODERUPLE"
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                    class: "block border-0 bg-transparent sm:hidden",
                    type: "button",
                    "data-te-collapse-init": true,
                    "data-te-target": "#navbarSupportedContent3",
                    "aria-controls": "navbarSupportedContent3",
                    "aria-expanded": "false",
                    "aria-label": "Toggle navigation",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        class: "[&>svg]:w-7",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            viewBox: "0 0 24 24",
                            fill: "currentColor",
                            class: "h-7 w-7",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                "fill-rule": "evenodd",
                                d: "M3 6.75A.75.75 0 013.75 6h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 6.75zM3 12a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 12zm0 5.25a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75a.75.75 0 01-.75-.75z",
                                "clip-rule": "evenodd"
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    class: "!visible hidden basis-[100%] items-center sm:!flex sm:basis-auto",
                    id: "navbarSupportedContent3",
                    "data-te-collapse-item": true,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        class: "flex sm:gap-4 flex-col sm:flex-row",
                        "data-te-navbar-nav-ref": true,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "nav__links",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: " underline",
                                    href: "/home",
                                    children: "Home"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "nav__links",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: " underline",
                                    href: "/about",
                                    children: "About"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "nav__links",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: " underline",
                                    href: "/services",
                                    children: "Our Services"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "nav__links",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: " underline",
                                    href: "/admin",
                                    children: "Blogs"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "nav__links",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: " underline",
                                    href: "/contact",
                                    children: "Contact Us"
                                })
                            })
                        ]
                    })
                })
            ]
        })
    }));
};
/* harmony default export */ const components_Navbar = (Navbar);


/***/ })

};
;