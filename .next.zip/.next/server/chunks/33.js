"use strict";
exports.id = 33;
exports.ids = [33];
exports.modules = {

/***/ 4033:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_SwiperUI)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/swiper/react/swiper-react.js + 13 modules
var swiper_react = __webpack_require__(2546);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.esm.js + 89 modules
var swiper_esm = __webpack_require__(6523);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.min.css
var swiper_min = __webpack_require__(8722);
// EXTERNAL MODULE: ./node_modules/swiper/modules/pagination/pagination.min.css
var pagination_min = __webpack_require__(2996);
// EXTERNAL MODULE: ./node_modules/swiper/modules/navigation/navigation.min.css
var navigation_min = __webpack_require__(9176);
;// CONCATENATED MODULE: ./src/Images/software-developer.png
/* harmony default export */ const software_developer = ({"src":"/_next/static/media/software-developer.77174fc0.png","height":1035,"width":1728,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAg0lEQVR42gWAsQqCQABA3zkIDiKIgyeFtFhgkeJwV0eQTdLQ0FJDRYtD1hBRDRbU0IcHjI8UDeqBeVu6xXzI7wzO0J2IaEpcYV7oL/MfxZOkAVsg8Hzpq0O6PHn6RnolqbGdOPNGQb9Uq7rc7qXeEa1Fb0PHCfNgCLizi6xa3ExYEC7+YuUUun5+F/EAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/Images/webdev.png
/* harmony default export */ const webdev = ({"src":"/_next/static/media/webdev.9818a913.png","height":1037,"width":1728,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAiElEQVR42gF9AIL/AFh7xWGBxQVewzZjtDRktAZfw2KBxld7xQAiY8ElZMQnZbxYeLRTbq8qY7seY8QpZcIAKmO7AE2uf5jG6ezr4eHddpDAAFKuKWG4AERuvj5otG2EwsbF0b7AzmV/vUJosD9puAAkY8EFX8JCbsLR1OPR1ORFbb4AXL4jYr+Atj3ZSXkpsAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/components/SwiperUI.js




// import "../styles/globals.css";





const SwiperUI = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(swiper_react/* Swiper */.tq, {
        // pagination={{
        //   clickable: true,
        // }}
        className: "carousel-slider",
        parallax: true,
        speed: 600,
        modules: [
            swiper_esm/* Parallax */.VS,
            swiper_esm/* Pagination */.tl,
            swiper_esm/* Navigation */.W_
        ],
        navigation: true,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " absolute top-0 left-0 w-[130%] max-w-none  h-screen object-cover ",
                slot: "container-start",
                src: software_developer,
                "data-swiper-parallax": "-23%",
                alt: "carousel.jpgs"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center flex h-screen",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex flex-col gap-5   items-center sm:items-start text-center sm:text-start  responsive-container absolute top-1/3 text-white",
                        "data-swiper-parallax": "-300",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-4xl sm:text-7xl font-semibold",
                                children: "Hero main title"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-2 items-center sm:items-start ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-2xl sm:text-5xl font-extralight",
                                        children: "Hero subtitle description"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "w-1/2 text-sm sm:text-base ",
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Torem ipsum dolor sit amet, consectetur adipiscing elit."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "rounded-full bg-[#6096BA] p-3 sm:w-1/5 w-1/3",
                                children: "Read More"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center flex h-screen",
                    "data-swiper-parallax": "-200",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex flex-col gap-5   items-center sm:items-start text-center sm:text-start  responsive-container absolute top-1/3 text-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-4xl sm:text-7xl font-semibold",
                                children: "Hero main title"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-2 items-center sm:items-start ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-2xl sm:text-5xl font-extralight",
                                        children: "Is this working?"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "w-1/2  text-sm sm:text-base ",
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Torem ipsum dolor sit amet, consectetur adipiscing elit."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "rounded-full bg-[#6096BA] p-3 sm:w-1/5 w-1/3",
                                children: "Read More"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center flex h-screen",
                    "data-swiper-parallax": "-100",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex flex-col gap-5   items-center sm:items-start text-center sm:text-start  responsive-container absolute top-1/3 text-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-4xl sm:text-7xl font-semibold",
                                children: "Hero main title"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-2 items-center sm:items-start ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-2xl sm:text-5xl font-extralight",
                                        children: "This is working!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "w-1/2 text-sm sm:text-base ",
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Torem ipsum dolor sit amet, consectetur adipiscing elit."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "rounded-full bg-[#6096BA] p-3 sm:w-1/5 w-1/3",
                                children: "Read More"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const components_SwiperUI = (SwiperUI);


/***/ })

};
;