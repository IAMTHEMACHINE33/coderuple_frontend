"use strict";
(() => {
var exports = {};
exports.id = 866;
exports.ids = [866];
exports.modules = {

/***/ 6953:
/***/ ((module) => {

module.exports = require("follow-redirects");

/***/ }),

/***/ 8941:
/***/ ((module) => {

module.exports = require("form-data");

/***/ }),

/***/ 3149:
/***/ ((module) => {

module.exports = require("proxy-from-env");

/***/ }),

/***/ 271:
/***/ ((module) => {

module.exports = require("sweetalert2");

/***/ }),

/***/ 2361:
/***/ ((module) => {

module.exports = require("events");

/***/ }),

/***/ 3685:
/***/ ((module) => {

module.exports = require("http");

/***/ }),

/***/ 5687:
/***/ ((module) => {

module.exports = require("https");

/***/ }),

/***/ 2781:
/***/ ((module) => {

module.exports = require("stream");

/***/ }),

/***/ 7310:
/***/ ((module) => {

module.exports = require("url");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("util");

/***/ }),

/***/ 9796:
/***/ ((module) => {

module.exports = require("zlib");

/***/ }),

/***/ 2373:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "aboutUsApi": () => (/* binding */ aboutUsApi),
/* harmony export */   "postContactUsApi": () => (/* binding */ postContactUsApi),
/* harmony export */   "publicRequest": () => (/* binding */ publicRequest),
/* harmony export */   "servicesApi": () => (/* binding */ servicesApi)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4047);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(271);
/* harmony import */ var sweetalert2__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(sweetalert2__WEBPACK_IMPORTED_MODULE_0__);


const publicRequest = axios__WEBPACK_IMPORTED_MODULE_1__/* ["default"].create */ .Z.create({
    baseURL: "http://localhost:90/"
});
async function aboutUsApi(props) {
    console.log(props);
    await publicRequest.get("aboutus/get").then((res)=>{
        props?.setAboutUs(res);
    }).catch((err)=>console.log(err));
}
async function servicesApi(props) {
    console.log(props);
    await publicRequest.get("service/get/").then((res)=>{
        props?.setServices(res);
    }).catch((err)=>console.log(err));
}
async function postContactUsApi(props) {
    console.log(props);
    await publicRequest.post("inquiry/add/", props?.data).then((res)=>{
        if (res?.data?.success) {
            sweetalert2__WEBPACK_IMPORTED_MODULE_0___default().fire("Good job!", "You clicked the button!", "success");
        }
        props.setSubmitting(false);
        props.reset();
    }).catch((err)=>console.log(err));
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [47], () => (__webpack_exec__(2373)));
module.exports = __webpack_exports__;

})();