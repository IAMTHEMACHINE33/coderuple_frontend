"use strict";
exports.id = 382;
exports.ids = [382];
exports.modules = {

/***/ 4976:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/about.9804d24e.svg","height":595,"width":845,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 9511:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cardmobile.1b610327.svg","height":772,"width":846,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 6434:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/cardui.c8d31c5a.svg","height":597,"width":563,"blurWidth":0,"blurHeight":0});

/***/ }),

/***/ 8300:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _Images_company_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1086);
/* harmony import */ var _Images_about_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4976);





const Aboutushome = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "relative bg-[ #E7E9F0] flex justify-center",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "responsive-container flex flex-col  py-20 gap-6",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "flex flex-col gap-4 items-center md:items-start px-5 md:px-0",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "capitalize text-5xl font-semibold",
                            children: "About us"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                            className: "capitalize text-2xl font-medium",
                            children: "Transforming your vision into reality"
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "flex flex-col gap-4 text-center items-left ",
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex md:flex-row-reverse flex-col items-center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: _Images_about_svg__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z,
                                className: "h-60 w-auto md:w-1/2 rounded-md ",
                                alt: "image"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: " font-light md:w-1/2 text-left flex flex-col gap-5 px-5 pt-3 md:pt-0 md:px-0 items-center md:items-start",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: " Our passion and drive to deliver quality solutions have taken us to the boardroom of 200 yrs old company and coffee shop meetings in Orlando, Washington, Singapore, Tokyo, Beijing and Kathmandu. We love the challenge to deliver the best possible solution using the latest and future technologies. We understand that we are your extended TEAM."
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                        className: "bg-[#6096BA] text-white rounded-xl py-1 px-5 w-40",
                                        children: "Read More"
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Aboutushome);


/***/ }),

/***/ 2359:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Home_Services)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/Images/company.jpg
var company = __webpack_require__(1086);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/Home/Cardservice.jsx




const Cardservice = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex flex-col lg:flex-row flex-wrap justify-center gap-5 lg:w-4/12 lg:items-start",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: ` w-full lg:w-full flex flex-col  lg:flex-col justify-center items-center gap-7  ${props.reverse == true ? "sm:flex-row" : "sm:flex-row-reverse"}`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: props.images,
                    className: "h-52 w-auto md:w-full rounded-md bg-white",
                    alt: "image"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col justify-center ",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                            className: "capitalize text-2xl font-semibold text-center pb-3",
                            children: props.heading
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-center  font-light",
                            children: props.content
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Home_Cardservice = (Cardservice);

// EXTERNAL MODULE: ./src/Images/mobile.png
var mobile = __webpack_require__(4504);
// EXTERNAL MODULE: ./src/Images/one.svg
var one = __webpack_require__(2993);
// EXTERNAL MODULE: ./src/Images/two.svg
var two = __webpack_require__(7902);
;// CONCATENATED MODULE: ./src/components/Home/Services.jsx






const Services = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "relative bg-[#D9D9D9] flex  justify-center text-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " flex  justify-center responsive-container",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "py-20 flex flex-col gap-10 w-full ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "capitalize text-5xl font-semibold",
                        children: "Our Services"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col  lg:flex-row  gap-10",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_Cardservice, {
                                heading: "Mobile Development",
                                content: `Our team works closely with clients to transform their ideas into user-friendly 
                        mobile applications that are just a tap away. By collaborating as a group, we ensure that every
                         project meets our clients needs and exceeds their expectations.`,
                                images: mobile/* default */.Z
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_Cardservice, {
                                reverse: true,
                                heading: "Web Development",
                                content: `At our company, we collaborate as a team to bring our clients' unique web
                         application design ideas to life. Our goal is to deliver a customised solution that meets
                          their needs and exceeds their expectations.`,
                                images: one/* default */.Z
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_Cardservice, {
                                heading: "UI/UX Design",
                                content: `Our Design Team work closely with clients to transform their 
                        Application Vision into Reality Our team of skilled designers. has extensive experience in 
                        creating user-friendly applications that provide a seamless user experience.`,
                                images: two/* default */.Z
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Home_Services = (Services);


/***/ }),

/***/ 4570:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _Images_logo_png__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2573);
/* harmony import */ var _Images_company_jpg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1086);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2996);
/* harmony import */ var swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(swiper_css_pagination__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(8722);
/* harmony import */ var swiper_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(swiper_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2546);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6523);








const Testimonials = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: "relative flex justify-center my-20",
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-col gap-10 responsive-container",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
                            className: "capitalize text-5xl font-semibold text-center",
                            children: "Ask our clients"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_6__/* .Swiper */ .tq, {
                            slidesPerView: 1,
                            spaceBetween: 10,
                            loop: true,
                            breakpoints: {
                                "@0.00": {
                                    slidesPerView: 1,
                                    spaceBetween: 10
                                },
                                "@0.75": {
                                    slidesPerView: 2,
                                    spaceBetween: 20
                                },
                                "@1.00": {
                                    slidesPerView: 3,
                                    spaceBetween: 40
                                }
                            },
                            modules: [],
                            className: "mySwiper",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-5 p-5 text-center items-center ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "rounded-full border-2 w-40 h-40 ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                    src: _Images_logo_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                                    className: "  ",
                                                    alt: "testimonial.jpg"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "leading-tight w-1/2 sm:w-auto  font-light",
                                                children: "We design experiences that are personalized to your users context and motivations. We use design thinking and it leads to design that"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-5 p-5 text-center items-center ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "rounded-full flex align-middle items-center border-2 w-40 h-40 ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                    src: _Images_company_jpg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                                                    className: " w-full h-full border-2 ",
                                                    alt: "testimonial.jpg"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "leading-tight w-1/2 sm:w-auto  font-light",
                                                children: "We design experiences that are personalized to your users context and motivations. We use design thinking and it leads to design that"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-5 p-5 text-center items-center ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "rounded-full border-2 w-40 h-40 ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                    src: _Images_logo_png__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z,
                                                    className: "rounded-full  ",
                                                    alt: "testimonial.jpg"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "leading-tight w-1/2 sm:w-auto  font-light",
                                                children: "We design experiences that are personalized to your users context and motivations. We use design thinking and it leads to design that"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_6__/* .SwiperSlide */ .o5, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex flex-col gap-5 p-5 text-center items-center ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                className: "rounded-full flex align-middle items-center border-2 w-40 h-40 ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                    src: _Images_company_jpg__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z,
                                                    className: "rounded-full w-full h-full  ",
                                                    alt: "testimonial.jpg"
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                className: "leading-tight w-1/2 sm:w-auto  font-light",
                                                children: "We design experiences that are personalized to your users context and motivations. We use design thinking and it leads to design that"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Testimonials);


/***/ }),

/***/ 9828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Whyus)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./src/Images/company.jpg
var company = __webpack_require__(1086);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/components/Home/Cardwhyus.jsx




const Cardwhyus = (props)=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "flex flex-row flex-wrap w-full md:w-[48%]   ",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: `flex flex-col ${props.reverse == true ? "sm:flex-row-reverse" : "sm:flex-row"} md:flex-row items-center gap-5`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    src: props.image,
                    className: "h-40 w-40 rounded-full bg-white",
                    alt: "image"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex flex-col gap-2",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                            className: "capitalize text-2xl font-semibold text-center md:text-left",
                            children: props.heading
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "text-left  font-light",
                            children: props.Content
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const Home_Cardwhyus = (Cardwhyus);

// EXTERNAL MODULE: ./src/Images/cardui.svg
var cardui = __webpack_require__(6434);
// EXTERNAL MODULE: ./src/Images/deliver.svg
var deliver = __webpack_require__(7275);
// EXTERNAL MODULE: ./src/Images/plan.svg
var plan = __webpack_require__(7806);
// EXTERNAL MODULE: ./src/Images/cardmobile.svg
var cardmobile = __webpack_require__(9511);
;// CONCATENATED MODULE: ./src/components/Home/Whyus.jsx







const Content = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "relative flex justify-center bg-[#D9D9D9] ",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " flex  justify-center responsive-container py-20",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " flex flex-col gap-5 items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "capitalize text-5xl font-semibold",
                        children: "Why Us?"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-xl",
                        children: "Your ingenious ideas. Our state-of-the-art web development"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-row md:flex-row lg:gap-8 flex-wrap pt-3",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_Cardwhyus, {
                                heading: "Innovation",
                                Content: "Bring us your wildest ideas and with our creative mindset and tools we’ll make it happen. Our team will\xa0 help you develop an online business strategy to outplay your competitors.",
                                image: cardui/* default */.Z
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_Cardwhyus, {
                                reverse: true,
                                heading: "Customer Service",
                                Content: "Customer satisfaction is our main priority.Our team will be always available to solve any issues through multiple communication channel such as phone, email, text",
                                image: deliver/* default */.Z
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_Cardwhyus, {
                                heading: "Professional team",
                                Content: "We are a professional web development company with a team of tech savvies who are always on top of latest trends in web development, web design, SEO and marketing",
                                image: plan/* default */.Z
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Home_Cardwhyus, {
                                reverse: true,
                                heading: "Quality",
                                Content: "Our main focus on building any product will be on quality.We want to provide only quality services to you which meets your needs and requirement.",
                                image: cardmobile/* default */.Z
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const Whyus = (Content);


/***/ }),

/***/ 4033:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_SwiperUI)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/swiper/react/swiper-react.js + 13 modules
var swiper_react = __webpack_require__(2546);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.esm.js + 89 modules
var swiper_esm = __webpack_require__(6523);
// EXTERNAL MODULE: ./node_modules/swiper/swiper.min.css
var swiper_min = __webpack_require__(8722);
// EXTERNAL MODULE: ./node_modules/swiper/modules/pagination/pagination.min.css
var pagination_min = __webpack_require__(2996);
// EXTERNAL MODULE: ./node_modules/swiper/modules/navigation/navigation.min.css
var navigation_min = __webpack_require__(9176);
;// CONCATENATED MODULE: ./src/Images/software-developer.png
/* harmony default export */ const software_developer = ({"src":"/_next/static/media/software-developer.77174fc0.png","height":1035,"width":1728,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAg0lEQVR42gWAsQqCQABA3zkIDiKIgyeFtFhgkeJwV0eQTdLQ0FJDRYtD1hBRDRbU0IcHjI8UDeqBeVu6xXzI7wzO0J2IaEpcYV7oL/MfxZOkAVsg8Hzpq0O6PHn6RnolqbGdOPNGQb9Uq7rc7qXeEa1Fb0PHCfNgCLizi6xa3ExYEC7+YuUUun5+F/EAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/Images/webdev.png
/* harmony default export */ const webdev = ({"src":"/_next/static/media/webdev.9818a913.png","height":1037,"width":1728,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAFCAIAAAD38zoCAAAAiElEQVR42gF9AIL/AFh7xWGBxQVewzZjtDRktAZfw2KBxld7xQAiY8ElZMQnZbxYeLRTbq8qY7seY8QpZcIAKmO7AE2uf5jG6ezr4eHddpDAAFKuKWG4AERuvj5otG2EwsbF0b7AzmV/vUJosD9puAAkY8EFX8JCbsLR1OPR1ORFbb4AXL4jYr+Atj3ZSXkpsAAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":5});
;// CONCATENATED MODULE: ./src/components/SwiperUI.js




// import "../styles/globals.css";





const SwiperUI = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(swiper_react/* Swiper */.tq, {
        // pagination={{
        //   clickable: true,
        // }}
        className: "carousel-slider",
        parallax: true,
        speed: 600,
        modules: [
            swiper_esm/* Parallax */.VS,
            swiper_esm/* Pagination */.tl,
            swiper_esm/* Navigation */.W_
        ],
        navigation: true,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                className: " absolute top-0 left-0 w-[130%] max-w-none  h-screen object-cover ",
                slot: "container-start",
                src: software_developer,
                "data-swiper-parallax": "-23%",
                alt: "carousel.jpgs"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center flex h-screen",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex flex-col gap-5   items-center sm:items-start text-center sm:text-start  responsive-container absolute top-1/3 text-white",
                        "data-swiper-parallax": "-300",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-4xl sm:text-7xl font-semibold",
                                children: "Welcome to Coderuple,"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-2 items-center sm:items-start ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-2xl sm:text-5xl font-extralight",
                                        children: "Where your digital needs come to life!              "
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "w-1/2 text-sm sm:text-base   ",
                                        children: "We deliver high-quality products and services ensuring all our customers are satisfied."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "rounded-full bg-[#6096BA] p-3 sm:w-1/5 w-1/3",
                                children: "Read More"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center flex h-screen",
                    "data-swiper-parallax": "-200",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex flex-col gap-5   items-center sm:items-start text-center sm:text-start  responsive-container absolute top-1/3 text-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-4xl sm:text-7xl font-semibold",
                                children: "Hero main title"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-2 items-center sm:items-start ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-2xl sm:text-5xl font-extralight",
                                        children: "Is this working?"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "w-1/2  text-sm sm:text-base   ",
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Torem ipsum dolor sit amet, consectetur adipiscing elit."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "rounded-full bg-[#6096BA] p-3 sm:w-1/5 w-1/3",
                                children: "Read More"
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(swiper_react/* SwiperSlide */.o5, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "justify-center flex h-screen",
                    "data-swiper-parallax": "-100",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: " flex flex-col gap-5   items-center sm:items-start text-center sm:text-start  responsive-container absolute top-1/3 text-white",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "text-4xl sm:text-7xl font-semibold",
                                children: "Hero main title"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex flex-col gap-2 items-center sm:items-start ",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                        className: "text-2xl sm:text-5xl font-extralight",
                                        children: "This is working!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                        className: "w-1/2 text-sm sm:text-base   ",
                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Torem ipsum dolor sit amet, consectetur adipiscing elit."
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "rounded-full bg-[#6096BA] p-3 sm:w-1/5 w-1/3",
                                children: "Read More"
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const components_SwiperUI = (SwiperUI);


/***/ })

};
;