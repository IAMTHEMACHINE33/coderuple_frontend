const Bullet = () => {
    return (
        <div className="w-3 h-3 bg-gray-700 dark:bg-gray-300 rounded-full" />
    )
}

export default Bullet