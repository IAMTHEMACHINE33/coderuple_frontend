import Image from "next/image"
import microsoft_logo from "./microsoft_logo.png"

const TestimonialLists = () => {
    return (
        // <div className="grid grid-cols-4">
        //     <Image src={microsoft_logo} />
        //     <Image src={microsoft_logo} />
        //     <Image src={microsoft_logo} />
        //     <Image src={microsoft_logo} />
        //     <Image src={microsoft_logo} />
        //     <Image src={microsoft_logo} />
        //     <Image src={microsoft_logo} />
        // </div>
        <div class="slider">
            <div class="slider-row">jlhnkljnik</div>
        </div>
    )
}

export default TestimonialLists