const testimonialData = [
    { id: 1, company: 'Hello', description: 'World' },
    { id: 2, company: 'DataGridPro', description: 'is Awesome' },
    { id: 3, company: 'MUI', description: 'is Amazing' },
    { id: 4, company: 'Hello', description: 'World' },
    { id: 5, company: 'DataGridPro', description: 'is Awesome' },
    { id: 6, company: 'MUI', description: 'is Amazing' },
    { id: 7, company: 'Hello', description: 'World' },
    { id: 8, company: 'DataGridPro', description: 'is Awesome' },
    { id: 9, company: 'MUI', description: 'is Amazing' },
];

export default testimonialData