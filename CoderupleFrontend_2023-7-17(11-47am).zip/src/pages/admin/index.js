import AdminContainer from "@/components/Admin/AdminNavbar/AdminContainer"
const index = () => {
    return (


        <AdminContainer>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
            <div className="bg-black h-28">index</div>
        </AdminContainer>

    )
}

export default index