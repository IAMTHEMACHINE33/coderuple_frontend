import TestimonialsAdd from "@/components/Admin/Testimonials/TestimonialsAdd";
import AdminContainer from "../../../components/Admin/AdminNavbar/AdminContainer";


const add = () => {
    return (
        <AdminContainer>
            <TestimonialsAdd />
        </AdminContainer>
    )
}

export default add