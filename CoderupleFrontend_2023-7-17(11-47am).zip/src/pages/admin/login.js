import Adminlogin from "@/components/Admin/Adminlogin"
import React from 'react'

const login = () => {
  return (
<Adminlogin/>
    )
}

export default login